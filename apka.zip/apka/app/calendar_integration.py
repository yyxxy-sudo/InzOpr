import datetime
import os
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
#from msal import ConfidentialClientApplication
import requests
from O365 import Account

#import asyncio
#import configparser
#from msgraph.generated.models.o_data_errors.o_data_error import ODataError


class Graph:
    def __init__(self, config):
        self.settings = config

SCOPES = ["https://www.googleapis.com/auth/calendar.readonly"]

# Google Calendar
# Google Calendar
def get_google_calendar_events():
    token_path = os.path.join(os.path.dirname(__file__), "token.json")

    # Usuń istniejący plik token.json, jeśli istnieje
    if os.path.exists(token_path):
        os.remove(token_path)

    creds = None

    # Zawsze generuj nowy token
    flow = InstalledAppFlow.from_client_secrets_file(
        os.path.join(os.path.dirname(__file__), "credentials.json"), SCOPES
    )
    creds = flow.run_local_server(port=5001, access_type="offline", prompt="consent")

    # Zapisz nowo wygenerowany token
    with open(token_path, "w") as token:
        token.write(creds.to_json())

    try:
        service = build("calendar", "v3", credentials=creds)
        now = datetime.datetime.utcnow().isoformat() + "Z"
        events_result = service.events().list(
            calendarId="primary", timeMin=now, maxResults=10, singleEvents=True, orderBy="startTime"
        ).execute()
        events = events_result.get("items", [])

        if not events:
            print("No upcoming events found.")
            return []

        return events
    except Exception as error:
        print(f"An error occurred: {error}")
        return {"error": str(error)}

def get_google_meet_events():
    # Pobieramy wydarzenia z Google Calendar
    events = get_google_calendar_events()
    # Filtrujemy tylko te z hangoutLink (Google Meet)
    meet_events = [event for event in events if "hangoutLink" in event]
    return meet_events


# Microsoft Teams
def get_ms_calendar_events(client_id, client_secret):
    credentials = (client_id, client_secret)
    scopes = ['Calendars.Read']
    account = Account(credentials)

    if not account.is_authenticated:
        account.authenticate(scopes=scopes)
        print('Authenticated!')

    schedule = account.schedule()
    calendar = schedule.get_default_calendar()
    events_generator = calendar.get_events(include_recurring=False)

    events = []
    for event in events_generator:
        events.append(str(event))
    return events

# Zoom (przykład integracji)
ZOOM_CLIENT_ID = "FA1BsrIaTHyB5zmz2hukmg"
ZOOM_CLIENT_SECRET = "dpQeeLxZBAqFFaEpevt2WmAv1J81jtmJ"
ZOOM_REDIRECT_URI = "https://5fb4-83-10-66-206.ngrok-free.app/zoom/callback"

import base64
import requests

# Ustaw odpowiednie wartości
ZOOM_CLIENT_ID = "FA1BsrIaTHyB5zmz2hukmg"
ZOOM_CLIENT_SECRET = "dpQeeLxZBAqFFaEpevt2WmAv1J81jtmJ"
ZOOM_REDIRECT_URI = "https://5fb4-83-10-66-206.ngrok-free.app/zoom/callback"


def get_zoom_access_token(auth_code):
    token_url = "https://zoom.us/oauth/token"

    # Utwórz nagłówki z zakodowanym Client ID i Client Secret
    auth_header = base64.b64encode(f"{ZOOM_CLIENT_ID}:{ZOOM_CLIENT_SECRET}".encode()).decode()
    headers = {
        "Authorization": f"Basic {auth_header}",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    # Payload z parametrami żądania
    payload = {
        "grant_type": "authorization_code",
        "code": auth_code,
        "redirect_uri": ZOOM_REDIRECT_URI
    }

    try:
        # Wysyłamy żądanie POST do Zoom API
        response = requests.post(token_url, headers=headers, data=payload)

        # Jeśli odpowiedź jest poprawna (200 OK)
        if response.status_code == 200:
            return response.json()
        else:
            # Logowanie błędu, jeśli wystąpi
            error_details = response.json()
            raise Exception(f"Error fetching token: {error_details}")
    except Exception as e:
        raise Exception(f"Failed to fetch Zoom token: {e}")


def get_zoom_events(access_token):
    url = "https://api.zoom.us/v2/users/me/meetings"
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json().get("meetings", [])
    else:
        raise Exception(f"Error fetching meetings: {response.json()}")
