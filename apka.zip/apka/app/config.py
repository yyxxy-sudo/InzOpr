ZOOM_CLIENT_ID = "FA1BsrIaTHyB5zmz2hukmg"
ZOOM_CLIENT_SECRET = "dpQeeLxZBAqFFaEpevt2WmAv1J81jtmJ"
ZOOM_REDIRECT_URI = "https://5fb4-83-10-66-206.ngrok-free.app/zoom/callback" # Ustaw identyczne w aplikacji Zoom
