import os
from flask import Flask
from routes import main

print("Current working directory:", os.getcwd())

app = Flask(__name__)

# Ustawienie klucza sesji
app.secret_key = "123"

# Rejestracja blueprinta
app.register_blueprint(main)

if __name__ == "__main__":
    app.run(debug=True)
