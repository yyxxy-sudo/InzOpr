from flask import Blueprint, jsonify, request, redirect, session
import smtplib
from email.mime.text import MIMEText
from calendar_integration import (
    get_google_calendar_events,
    get_google_meet_events,
    get_ms_calendar_events,
    get_zoom_events,
    get_zoom_access_token,
)

main = Blueprint("main", __name__)

# Konfiguracja Zoom
ZOOM_CLIENT_ID = "FA1BsrIaTHyB5zmz2hukmg"
ZOOM_CLIENT_SECRET = "dpQeeLxZBAqFFaEpevt2WmAv1J81jtmJ"
ZOOM_REDIRECT_URI = "https://5fb4-83-10-66-206.ngrok-free.app/zoom/callback"

# Konfiguracja serwera e-mail
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_ADDRESS = "jfurtak03@gmail.com"  # Wstaw swój adres e-mail
EMAIL_PASSWORD = "twoje_haslo"  # Wstaw hasło lub App Password


# Funkcja do wysyłania maili
def send_email(recipient_email, subject, body):
    try:
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = recipient_email

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.sendmail(EMAIL_ADDRESS, recipient_email, msg.as_string())
            print(f"Email wysłany do: {recipient_email}")
    except Exception as e:
        print(f"Błąd wysyłania maila: {e}")


# Endpoint: Pobieranie wydarzeń z Google Calendar
@main.route("/events", methods=["GET"])
def events():
    user_email = request.args.get("email")
    if not user_email:
        return jsonify({"error": "Brak adresu e-mail w zapytaniu"}), 400

    try:
        events = get_google_calendar_events()
        send_email(user_email, "Wydarzenia Google Calendar", "Oto Twoje wydarzenia z Google Calendar.")
        return jsonify({"message": "E-mail wysłany pomyślnie", "events": events})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Endpoint: Pobieranie wydarzeń z Google Meets
@main.route("/google-meets", methods=["GET"])
def google_meets():
    user_email = request.args.get("email")
    if not user_email:
        return jsonify({"error": "Brak adresu e-mail w zapytaniu"}), 400

    try:
        meet_events = get_google_meet_events()
        send_email(user_email, "Wydarzenia Google Meet", "Oto Twoje wydarzenia z Google Meet.")
        return jsonify({"message": "E-mail wysłany pomyślnie", "meet_events": meet_events})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Endpoint: Autoryzacja Zoom
@main.route("/zoom/login")
def zoom_login():
    auth_url = (
        "https://zoom.us/oauth/authorize"
        f"?response_type=code&client_id={ZOOM_CLIENT_ID}"
        f"&redirect_uri={ZOOM_REDIRECT_URI}"
    )
    return redirect(auth_url)


# Callback Zoom po autoryzacji
@main.route("/zoom/callback")
def zoom_callback():
    auth_code = request.args.get("code")
    if not auth_code:
        return jsonify({"error": "Authorization code not found"}), 400

    try:
        token_data = get_zoom_access_token(auth_code)
        access_token = token_data["access_token"]

        session["zoom_access_token"] = access_token
        return jsonify({"access_token": access_token})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Endpoint: Pobieranie wydarzeń z Zoom
@main.route("/zoom/events", methods=["GET"])
def zoom_events():
    access_token = session.get("zoom_access_token")
    user_email = request.args.get("email")
    if not user_email:
        return jsonify({"error": "Brak adresu e-mail w zapytaniu"}), 400

    if not access_token:
        return jsonify({"error": "User not authenticated with Zoom"}), 401

    try:
        events = get_zoom_events(access_token)
        send_email(user_email, "Wydarzenia Zoom", "Oto Twoje nadchodzące wydarzenia z Zoom.")
        return jsonify({"message": "E-mail wysłany pomyślnie", "events": events})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Endpoint: Pobieranie wydarzeń z Microsoft Teams
@main.route("/ms-calendar", methods=["GET"])
def ms_calendar():
    user_email = request.args.get("email")
    if not user_email:
        return jsonify({"error": "Brak adresu e-mail w zapytaniu"}), 400

    try:
        client_id = "3afebc81-6ecc-4b0c-921f-010ffcd0a5d4"
        tenant_id = "f8cdef31-a31e-4b4a-93e4-5f571e91255a"
        client_secret = "9yb8Q~6tjeD0EjLqkiU6oCPEnCVjE5nSvrebZcyI"

        events = get_ms_calendar_events(client_id, tenant_id, client_secret)
        send_email(user_email, "Wydarzenia Microsoft Teams", "Oto Twoje wydarzenia z Microsoft Teams.")
        return jsonify({"message": "E-mail wysłany pomyślnie", "events": events})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Endpoint: Wylogowanie z Zoom
@main.route("/zoom/logout", methods=["GET"])
def zoom_logout():
    try:
        session.pop("zoom_access_token", None)
        return jsonify({"message": "Logged out successfully. You can now log in with another account."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
