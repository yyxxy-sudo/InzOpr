import smtplib
from email.mime.text import MIMEText

# Konfiguracja serwera SMTP
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_ADDRESS = "jfurtak03@gmail.com"  # Twój adres Gmail
EMAIL_PASSWORD = "cacd tkrt pjrb rknl"  # Twoje hasło Gmail lub App Password


def send_email(recipients, subject, body):
    """
    Funkcja do wysyłania wiadomości e-mail za pomocą SMTP.

    :param recipients: Lista adresów e-mail odbiorców (lub pojedynczy adres jako string)
    :param subject: Temat wiadomości
    :param body: Treść wiadomości
    """
    try:
        # Jeżeli recipients to string, zamień go na listę
        if isinstance(recipients, str):
            recipients = [recipients]

        # Tworzenie wiadomości
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = ", ".join(recipients)  # Formatowanie listy odbiorców

        # Połączenie z serwerem SMTP
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()  # Szyfrowanie TLS
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)  # Logowanie do serwera
            server.sendmail(EMAIL_ADDRESS, recipients, msg.as_string())  # Wysłanie wiadomości
            print(f"E-mail wysłany pomyślnie do: {', '.join(recipients)}")
    except Exception as e:
        print(f"Błąd wysyłania maila: {e}")


# Test funkcji
if __name__ == "__main__":
    # Dane testowe
    recipient_emails = ["julka.mik03@gmail.com", "olusia1599@gmail.com", "jfurtak03@gmail.com"]  # Adresy odbiorców
    subject = "atak"  # Temat wiadomości
    body = "to napad, rece do gory, masz 10 sekund zeby zaplacic okup albo komputer wybuchnie"  # Treść wiadomości

    # Wywołanie funkcji
    send_email(recipient_emails, subject, body)
