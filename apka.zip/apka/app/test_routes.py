import unittest
from flask import session
from main import app

class TestRoutes(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        self.client.testing = True

    def test_events(self):
        response = self.client.get("/events")
        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.json, list)

    def test_google_meets(self):
        response = self.client.get("/google-meets")
        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.json, list)

    def test_zoom_login(self):
        response = self.client.get("/zoom/login", follow_redirects=False)
        self.assertEqual(response.status_code, 302)  # Redirect to Zoom login
        self.assertIn("zoom.us/oauth/authorize", response.headers["Location"])

    def test_zoom_callback_no_code(self):
        response = self.client.get("/zoom/callback")
        self.assertEqual(response.status_code, 400)
        self.assertIn("error", response.json)

    def test_zoom_events_no_auth(self):
        response = self.client.get("/zoom/events")
        self.assertEqual(response.status_code, 401)
        self.assertIn("error", response.json)

    def test_ms_calendar(self):
        response = self.client.get("/ms-calendar")
        self.assertIn(response.status_code, [200, 500])  # 500 if credentials are invalid
        self.assertIsInstance(response.json, (list, dict))

if __name__ == "__main__":
    unittest.main()
